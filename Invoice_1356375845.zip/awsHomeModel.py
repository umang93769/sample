import boto3
from datetime import datetime,timedelta
import json
from AWS.dimensions.GetDimension import Getdimention
class awshome():
    def __init__(self,data):
        boto = boto3.Session(
            aws_access_key_id='AKIAYODUIHLYMKNECS2I',
            aws_secret_access_key='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',
            region_name = 'us-east-1'
        )
        with open("regions.json", 'r') as file:
            self.regionslist = json.load(file)

        self.ce_client = boto.client('ce')

        self.end_date=data['end_date']
        end_date_obj = datetime.strptime(data['end_date'], '%Y-%m-%d')
        new_end_date_obj = end_date_obj + timedelta(days=1)
        data['end_date'] = new_end_date_obj.strftime('%Y-%m-%d')
        
        if "filter" not in data:
            print("Filter is not present in payload")
            self.query  = {
                "TimePeriod": {
                    'Start': data['start_date'],
                    'End': data['end_date']
                },
                "Granularity": data['Granularity'],
                "Metrics": [data['type']],
                "GroupBy": []
            }
        
        else:
            print("filter present")
            if((len(data['filter']) == 1)):
                self.query =  {
                    'TimePeriod': {
                        'Start': data['start_date'],
                        'End': data['end_date']
                    },
                    'Granularity':  data['Granularity'],
                    'Filter': {   
                            'Dimensions': {
                                # 'Key': 'SERVICE',
                                # 'Values': ['Amazon Simple Storage Service']
                            }
                    },
                    'Metrics': [data['type']],
                    'GroupBy' : []  
                }

                self.query['Filter']['Dimensions']['Key'] = list(data['filter'][0].keys())[0]
                # self.query['Filter']['Dimensions']['Values'] = list(data['filter'][0].values())[0]
                #testing

                if isinstance(data['filter'][0][list(data['filter'][0].keys())[0]],list):
                    self.query['Filter']['Dimensions']['Values'] = data['filter'][0][list(data['filter'][0].keys())[0]]

                else:
                    for eachDataFilter in data['filter']:
                        value_chart = []
                        for values in list(eachDataFilter.values()):
                            value_chart.append(values)

                    self.query['Filter']['Dimensions']['Values'] = value_chart

            
            elif (len(data['filter']) > 1 ):
                
                self.query = {
                    'TimePeriod': {
                        'Start': data['start_date'],
                        'End': data['end_date']
                    },
                    'Granularity': data['Granularity'],
                    'Filter': {
                        'And': [
                        ]
                    },
                    'Metrics': [data['type']],
                    'GroupBy' : []  
                }
                
                for eachDataFilter in data['filter']:
                    EachFilterDict = {}

                    value_chart = []
                    
                    if isinstance(eachDataFilter[list(eachDataFilter.keys())[0]],list):
                        value_chart = eachDataFilter[list(eachDataFilter.keys())[0]]
                    else:
                        for values in list(eachDataFilter.values()):
                            value_chart.append(values)

                    EachFilterDict['Dimensions'] = {
                        'Key' : list(eachDataFilter.keys())[0],
                        'Values' : value_chart
                    }
                    self.query['Filter']['And'].append(EachFilterDict) 
        
        try: 
            obj = {
                'Type' : list(data['GroupBy'][0].keys())[0],
                'Key' : list(data['GroupBy'][0].values())[0]
            } 
            self.query['GroupBy'].append(obj)   
            
        except:
            print("Group By Not present")

    def lastMonthCost(self,data):
        # print(self.query)
        response = self.ce_client.get_cost_and_usage(**self.query)
        cost = 0
        print(response)

        for record in response['ResultsByTime']:
            print(record)
            cost += round(float(record['Total'][data['type']]['Amount']),data['round'])

        cost = {
            "Start_Date":data['start_date'],
            "End_Date":self.end_date,
            "Cost" : round(cost,data['round'])
        }

        final_response={}
        final_response["dataMap"]=cost
        return final_response
    

    def currentMonthCost(self,data):
        # print(self.query)

        response = self.ce_client.get_cost_and_usage(**self.query)
        cost = 0
        print(response)

        for record in response['ResultsByTime']:
            print(record)
            cost += round(float(record['Total'][data['type']]['Amount']),data['round'])

        cost = {
            "Start_Date":data['start_date'],
            "End_Date":self.end_date,
            "Cost" : round(cost,data['round'])
        }
        final_response={}
        final_response["dataMap"]=cost
        return final_response
    
    def currentQuarterMonthCost(self,data):
        # print(self.query)

        response = self.ce_client.get_cost_and_usage(**self.query)
        cost = 0
        print(response)

        for record in response['ResultsByTime']:
            print(record)
            cost += round(float(record['Total'][data['type']]['Amount']),data['round'])

        cost = {
            "Start_Date":data['start_date'],
            "End_Date":self.end_date,
            "Cost" : round(cost,data['round'])
        }

        final_response={}
        final_response["dataMap"]=cost
        return final_response

    
    def customHomeCost(self,data):
        # print(self.query)

        response = self.ce_client.get_cost_and_usage(**self.query)
        cost = 0
        print(response)

        for record in response['ResultsByTime']:
            print(record)
            cost += round(float(record['Total'][data['type']]['Amount']),data['round'])

        cost = {
            "Start_Date":data['start_date'],
            "End_Date":self.end_date,
            "Cost" : round(cost,data['round'])
        }
        final_response={}
        final_response["dataMap"]=cost
        return final_response
    
    def awshomeService(self,data):
        print(self.query)
        final_response={}
        data_map={}
        response = self.ce_client.get_cost_and_usage(**self.query)
        print(response)
        total_cost = 0.0
        pie={}
        results_by_time = response.get("ResultsByTime", [])
        combined_services = {}
        for result in results_by_time:
            for group in result.get("Groups", []):
                # Extract the "Keys" and "Metrics" data
                keys = group.get("Keys", [])
                metrics = group.get("Metrics", {})

                # Extract the cost amount
                cost_amount = metrics.get("UnblendedCost", {}).get("Amount", 0.0)

                # Get the service name
                service_name = keys[0] if keys else "Unknown"

                # Check if the service is one of the two to be combined
                if service_name == 'EC2 - Other' or service_name == 'Amazon Elastic Compute Cloud - Compute':
                    # If it's one of the two, combine the cost under 'Amazon Elastic Compute Cloud'
                    service_name = 'Amazon Elastic Compute Cloud'
                    combined_services.setdefault(service_name, {'Service': service_name, 'Cost($)': 0.0})
                    combined_services[service_name]['Cost($)'] += round(float(cost_amount),data['round'])
                    total_cost+=round(float(cost_amount),data['round'])
                else:
                    # If not one of the two, add it to the dictionary
                    if service_name in combined_services:
                        # If present, add the new cost to the previous value
                        combined_services[service_name]['Cost($)'] += round(float(cost_amount),data['round'])
                        total_cost+=round(float(cost_amount),data['round'])
                    else:
                        # If not present, create a new entry in the dictionary
                        combined_services[service_name] = {'Service': service_name, 'Cost($)': round(float(cost_amount),data['round'])}
                        total_cost+=round(float(cost_amount),data['round'])

        data_map["table"]=list(combined_services.values())
        data_map["totalcost"]=round(total_cost,data['round'])
        data_map["currencySymbol"]="$"
        data_map["tableKeys"]=["Service", "Cost($)"]
        pie["x"]=[ "Cost($)"]
        pie["y"]=["Service" ]
        data_map["pie"]=pie
        final_response["dataMap"]=data_map
        return final_response
        
    def awshomecostbyregion(self,data):
        print(self.query)
        final_response={}
        dataMap={}
        table=[]
        tablekeys=[]
        elastic_compute_added=False
        ec2_list=["EC2 - Other","Amazon Elastic Compute Cloud - Compute"]
        new_services=[]
        dimobj = Getdimention(data,"SERVICE")
        services=dimobj.getUsageTypeDimention()
        for service in services:
            if service == "EC2 - Other" or service == "Amazon Elastic Compute Cloud - Compute":
                # Add "Amazon Elastic Compute Cloud" if it hasn't been added yet
                if not elastic_compute_added:
                    new_services.append("Amazon Elastic Compute Cloud")
                    elastic_compute_added = True
            else:
                new_services.append(service)
        
        for service in new_services:
            record_mapper={}
            total_cost=0
            if service == "Amazon Elastic Compute Cloud":
                tmps=ec2_list
            else:
                tmps=[service]
            try:
                self.query['Filter']['Dimensions']['Values'] = tmps
            except:
                self.query['Filter']['And'][0]['Dimensions']['Values'] = tmps

            response = self.ce_client.get_cost_and_usage(**self.query)
            for time_period in response["ResultsByTime"]:
                for group in time_period["Groups"]:
                    region_key = group["Keys"][0]
                    tablekeys.append(self.regionslist.get(group["Keys"][0]))
                    cost = float(group["Metrics"][data['type']]["Amount"])
                    total_cost+=cost
                    if region_key not in record_mapper:
                        record_mapper[region_key] = cost
                    else:
                        record_mapper[region_key] += cost
            # Use the region_mapping to create the final result with region names
            final_result_with_names = {self.regionslist[region]: cost for region, cost in record_mapper.items()}
            for key, value in final_result_with_names.items():
                final_result_with_names[key] = round(value, data['round'])
            final_result_with_names['Total']=round(total_cost,data['round'])
            final_result_with_names["Service Name"]=service
            table.append(final_result_with_names)

        tablekeys=list(set(tablekeys))
        total={}
        total["Service Name"]="Total"
        for region in tablekeys:
            total[region]=0.0
        total['Total']=0.0
        for row in table:
            for key, value in row.items():
                if key != "Service Name":
                    total[key] = round((float(total[key]) + float(value)),data['round'])
        
        table.append(total)
        tablekeys.append("Service Name")
        tablekeys.append("Total")
        service_name_index = tablekeys.index("Service Name")
        tablekeys.insert(0, tablekeys.pop(service_name_index))
        dataMap['tableKeys']=tablekeys
        dataMap['table']=table
        dataMap['currencySymbol']="$"
        final_response["dataMap"]=dataMap
        
        return final_response

    def awshomeServiceovertime(self,data):
        print(self.query)
        final_response={}
        dataMap={}
        dimobj = Getdimention(data,"SERVICE")
        services=dimobj.getUsageTypeDimention()
        response = self.ce_client.get_cost_and_usage(**self.query)
        
        # Extract the ResultsByTime data
        results_by_time = response["ResultsByTime"]

        # Initialize a dictionary to store the parsed costs for each service
        parsed_costs = {}

        # Iterate through the time periods and update the parsed_costs dictionary
        for time_period in results_by_time:
            start_date = time_period["TimePeriod"]["Start"]
            for group in time_period["Groups"]:
                service_name = group["Keys"][0]
                cost_amount = float(group["Metrics"][data['type']]["Amount"])
                
                if service_name not in parsed_costs:
                    parsed_costs[service_name] = {}
                
                parsed_costs[service_name][start_date] = cost_amount

        final_result = []
        formatted_result=parsed_costs
        # Extract all unique dates from the formatted_result
        unique_dates = set(date for service_costs in formatted_result.values() for date in service_costs)

        # Iterate through the unique dates and create an object for each date
        for date in unique_dates:
            obj = {"date": date}
            total=0
            obj["Amazon Elastic Compute Cloud"] = round((
                formatted_result["EC2 - Other"].get(date, 0) +
                formatted_result["Amazon Elastic Compute Cloud - Compute"].get(date, 0)
            ),data['round'])
            total+=obj["Amazon Elastic Compute Cloud"]
            for service, service_costs in formatted_result.items():
                if service not in ["EC2 - Other", "Amazon Elastic Compute Cloud - Compute"]:
                    obj[service] = round(float(service_costs.get(date, 0)),data['round'])
                    total+=obj[service]
            obj["Total"]=total
            final_result.append(obj)

        # Print the final result
        dataMap["formattedChartData"]=final_result
        dataMap["currencySymbol"]="$"
        services.append("Total")
        dataMap["Services"]=services
        final_response["dataMap"]=dataMap

        return final_response
    