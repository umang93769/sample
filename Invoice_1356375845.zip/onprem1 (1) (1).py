import json
import sys
import requests
import urllib.parse
import openai

def create_file(group_name, project_name, access_token, file_path, commit_message,branch):

    with open("text.txt", "r") as f:
        content = f.read()

    headers = {"Private-Token": access_token}
    url = f"https://gitlab.com/api/v4/groups?search={group_name}"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        groups = response.json()
        if len(groups) == 0:
            print(f"No group found with the name '{group_name}'.")
            return

        group_id = groups[0]['id']
        url = f"https://gitlab.com/api/v4/groups/{group_id}/projects?search={project_name}"
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            projects = response.json()
            if len(projects) == 0:
                print(f"No project found with the name '{project_name}' in the group '{group_name}'.")
                return

            project_id = projects[0]['id']
            url = f"https://gitlab.com/api/v4/projects/{project_id}/repository/files/{file_path}"
            params = {
                "branch": branch,
                "content": content,
                "commit_message": commit_message
            }
            response = requests.post(url, headers=headers, params=params)

            if response.status_code == 201:
                print(f"File '{file_path}' created successfully.")
            else:
                print(f"Failed to create file '{file_path}'. Error: {response.text}")
        else:
            print(f"Failed to retrieve project '{project_name}' in the group '{group_name}'. Error: {response.text}")
    else:
        print(f"Failed to retrieve group '{group_name}'. Error: {response.text}")

def update_file_content(group_name, project_name, access_token, file_path, commit_message,branch):
    
    with open("text.txt", "r") as f:
        file_to_update_01_content = f.read()

    content = file_to_update_01_content
    print(content)

    headers = {"Private-Token": access_token}
    url = f"https://gitlab.com/api/v4/groups?search={group_name}"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        groups = response.json()
        if len(groups) == 0:
            print(f"No group found with the name '{group_name}'.")
            return

        group_id = groups[0]['id']
        url = f"https://gitlab.com/api/v4/groups/{group_id}/projects?search={project_name}"
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            projects = response.json()
            if len(projects) == 0:
                print(f"No project found with the name '{project_name}' in the group '{group_name}'.")
                return

            project_id = projects[0]['id']
            file_path = file_path.lstrip("/")  # Remove leading slashes from the file path
            url = f"https://gitlab.com/api/v4/projects/{project_id}/repository/files/{file_path}"
            params = {
                "branch":branch,
                "commit_message": commit_message,
                "content": content
            }
            response = requests.put(url, headers=headers, params=params)

            if response.status_code == 200:
                print(f"File '{file_path}' successfully updated.")
            else:
                print(f"Failed to update file '{file_path}'. Error: {response.text}")
        else:
            print(f"Failed to retrieve project '{project_name}' in the group '{group_name}'. Error: {response.text}")
    else:
        print(f"Failed to retrieve group '{group_name}'. Error: {response.text}")
    

def get_latest_commit_filepath(group_name, project_name, branch, access_token):
    headers = {"Private-Token": access_token}
    url = f"https://gitlab.com/api/v4/groups?search={group_name}"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        groups = response.json()
        if len(groups) == 0:
            print(f"No group found with the name '{group_name}'.")
            return

        group_id = groups[0]['id']
        url = f"https://gitlab.com/api/v4/groups/{group_id}/projects?search={project_name}"
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            projects = response.json()
            if len(projects) == 0:
                print(f"No project found with the name '{project_name}' in the group '{group_name}'.")
                return

            project_id = projects[0]['id']
            url = f"https://gitlab.com/api/v4/projects/{project_id}/repository/commits?per_page=1&ref_name={branch}"
            response = requests.get(url, headers=headers)

            if response.status_code == 200:
                commits = response.json()
                if len(commits) == 0:
                    print(f"No commits found in the project '{project_name}' for the branch '{branch}'.")
                    return

                latest_commit = commits[0]
                latest_commit_sha = latest_commit['id']

                url = f"https://gitlab.com/api/v4/projects/{project_id}/repository/commits/{latest_commit_sha}/diff"
                response = requests.get(url, headers=headers)

                if response.status_code == 200:
                    diff_files = response.json()
                    return diff_files[0]['new_path']
                else:
                    print(f"Failed to retrieve commit diff in the project '{project_name}'. Error: {response.text}")
            else:
                print(f"Failed to retrieve commits in the project '{project_name}' for the branch '{branch}'. Error: {response.text}")
        else:
            print(f"Failed to retrieve project '{project_name}' in the group '{group_name}'. Error: {response.text}")
    else:
        print(f"Failed to retrieve group '{group_name}'. Error: {response.text}")

def get_completion(prompt, model="gpt-3.5-turbo-16k-0613", temperature=0):

    messages = [{"role": "user", "content": prompt}]
    openai.api_key = "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"
    response = openai.ChatCompletion.create(

        model=model,

        messages=messages,

        temperature=temperature,
        request_timeout=300
    )

    return response.choices[0].message["content"]

def get_file_content(group_name, project_name, branch, access_token, file_path):
    headers = {"Private-Token": access_token}
    url = f"https://gitlab.com/api/v4/groups?search={group_name}"
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        groups = response.json()
        if len(groups) == 0:
            print(f"No group found with the name '{group_name}'.")
            return

        group_id = groups[0]['id']
        url = f"https://gitlab.com/api/v4/groups/{group_id}/projects?search={project_name}"
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            projects = response.json()
            if len(projects) == 0:
                print(f"No project found with the name '{project_name}' in the group '{group_name}'.")
                return

            project_id = projects[0]['id']
            url = f"https://gitlab.com/api/v4/projects/{project_id}/repository/files/{file_path}/raw?ref={branch}"
            response = requests.get(url, headers=headers)

            if response.status_code == 200:
                file_content = response.text
                return file_content
            else:
                print(f"Failed to retrieve file content for '{file_path}'. Error: {response.text}")
        else:
            print(f"Failed to retrieve project '{project_name}' in the group '{group_name}'. Error: {response.text}")
    else:
        print(f"Failed to retrieve group '{group_name}'. Error: {response.text}")

def smartwebunit(group_name,project_name,access_token,branch,file_path):
        
    encoded_path = urllib.parse.quote_plus(file_path)
    file_content=get_file_content(group_name, project_name, branch, access_token, encoded_path)
    print(file_content)
    
    # manualmsg = "write unit testcases for the above code using junit , just provide me the 100 % code. Ensure That package name would be com.brillio. Ensure that these import com.brillio.util.JwtUtil and import java.util.Date statements must be included in the code."
    
    manualmsg='''Write comprehensive unit test cases using junit for the JwtUtil class to ensure that it functions correctly. The package name must be com.brillio, and include the following import statements:
    package com.brillio;
    
    import com.brillio.util.JwtUtil;
    import org.junit.jupiter.api.Assertions;
    import org.junit.jupiter.api.BeforeEach;
    import org.junit.jupiter.api.Test;
    import org.springframework.security.core.userdetails.UserDetails;
    
    import java.util.Date;
    
    import static org.mockito.Mockito.mock;
    import static org.mockito.Mockito.when;'''
    
    prompt=file_content+ "  " +manualmsg
    
    response = get_completion(prompt)
    print (response)
    
    with open("text.txt","w") as f:
        f.write(response)

    extracted_path="src/test/java/com/brillio/JwtUtilTest.java"
    
    extracted_path=urllib.parse.quote_plus(extracted_path)

    commit_message="Latest unit test case"
    try:
        create_file(group_name, project_name, access_token, extracted_path, commit_message,branch)
        raise FileExistsError
    except FileExistsError:
        update_file_content(group_name, project_name, access_token, extracted_path, commit_message,branch)
        

def smartwebfunc(group_name,project_name,access_token,branch,file_path):
    encoded_path = urllib.parse.quote_plus(file_path)
    file_content=get_file_content(group_name, project_name, branch, access_token, encoded_path)
    print(file_content)

    encoded_path = urllib.parse.quote_plus('src/main/resources/static/transactions.html')
    premsg=get_file_content(group_name, project_name, branch, access_token, encoded_path)
    print(premsg)


    manualmsg='''You are tasked with automating the login process for a Smart Bank's website using Selenium WebDriver with Java.

    Your objective is to write Java code that achieves the following:
    1. Set up the Chrome WebDriver with the appropriate driver executable path with ChromeOptions configured to run in headless mode using "--headless" and disable the sandbox with "--no-sandbox".Set the system property for the ChromeDriver to "/usr/bin/chromedriver".Add The print statements as "Opening The Browser";
    2. Open the Chrome browser and navigate to the Smart Bank login page (URL: http://35.175.173.214:8081/).Wait for 5 seconds to ensure the page is loaded completely.Add The print statements as "Opening The URL: http://35.175.173.214:8081/".
    3. Create two String variables, username1 and password1, and set them to "krishnachavan" and "krishna@123" respectively.Print a message stating that you are entering an invalid user with stars to prevented credentials logging.
    4. Use Selenium WebDriver to create two new variables inputusername and inputpassword to locate the input fields for username and password using their CSS selectors.locate the username input field using the CSS selector "input#username".
    5. Enter the value of username1 into the inputusername input field.Enter the value of password1 into the password input field.
    6. Click the "Login" button to perform the login process.Wait for 5 seconds to ensure the credentials are entered..
    7. Find and check if the error message element is displayed on the page.
    8. If the error message is displayed, get the text of the error message and print it along with the used username and password.
    9. If the error message is not displayed, print "Error Message Element is not displayed."Add Thread.sleep(5000).
    10. Enter valid credentials (username: "krishna" and password: "brillio!2022") into the respective input fields on the login form.locate the username input field using the CSS selector "input#username".locate the password input field using the CSS selector "input#password".Clear the input field for the username and password to ensure it is empty.
    11. Click the "Login" button again to perform the login process by using find element css selector "button[type='submit']" .Wait for 5 seconds to ensure the credentials are entered.
    12. Verify the login success by comparing the current URL with the expected dashboard page URL (URL: http://35.175.173.214:8081/transactions.html). If successful, print the message along with the used username and password.Add Thread.sleep(5000).
    13.Print a message indicating that the code is finding the transaction button to click.
    14.Locate and click the first transaction button on the page using its CSS selector .
    15.Print a message indicating that the button has been clicked.
    16.Wait for 5 seconds.
    17.Find and retrieve transaction details (details, amount, and date) for the first transaction using their respective CSS selectors.
    18.Print the transaction details in a formatted manner, combining details, amount, and date.
    19.Print the details separately.
    20.Print the amount separately.
    21.Print the date separately.
    22.Print a message stating that the details for the first transaction have been fetched.
    23. Close the browser and quit the WebDriver.Add The print statements as "Closing the Browser".

    Write the Java code to automate the described login process using Selenium WebDriver with Java. Use the provided HTML code to locate and interact with the login page elements effectively.
    Ensure to follow this public static void main(String[] args) throws InterruptedException and public class LoginTest'''

    prompt=file_content + "\n\nTransactions.html\n\n" +premsg+"\n\n"+manualmsg

    response = get_completion(prompt)
    print (response)

    with open("text.txt","w") as f:
        f.write(response)

    extracted_path="src/functional/LoginTest.java"
    
    extracted_path=urllib.parse.quote_plus(extracted_path)

    commit_message="Latest functional test case"

    try:
        create_file(group_name, project_name, access_token, extracted_path, commit_message,branch)
        raise FileExistsError
    except FileExistsError:
        update_file_content(group_name, project_name, access_token, extracted_path, commit_message,branch)

if __name__ == "__main__":
    
    group_name = sys.argv[1]
    project_name = sys.argv[2]
    access_token = sys.argv[3]
    branch = sys.argv[4]
 
    file_path=get_latest_commit_filepath(group_name, project_name, branch, access_token)
    
    if "html" in file_path:
        smartwebfunc(group_name,project_name,access_token,branch,file_path)
    else:
        smartwebunit(group_name,project_name,access_token,branch,file_path)
    
    